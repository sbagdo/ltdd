
import kotlin.math.PI
import kotlin.math.sqrt

// ==========================================
// BÀI 2 - LỚP, DANH SÁCH, VÒNG LẶP, CHUỖI
// ==========================================


// ------------------------------------------
// 1. LỚP TRỪU TƯỢNG
// 2. THUỘC TÍNH TRỪU TƯỢNG
// 3. PHƯƠNG THỨC TRỪU TƯỢNG
// ------------------------------------------

abstract class DongVat {

    // Thuộc tính trừu tượng
    abstract val ten: String

    // Phương thức trừu tượng
    abstract fun phatRaAmThanh()

    // Phương thức thông thường
    fun ngu() {
        println("$ten đang ngủ.")
    }
}


// ------------------------------------------
// 4. LỚP open VÀ LỚP CON
// ------------------------------------------

open class PhuongTien(val ten: String) {

    open fun diChuyen() {
        println("$ten đang di chuyển.")
    }
}


// ------------------------------------------
// 5. TẠO LỚP CON BẰNG KẾ THỪA
// 6. GHI ĐÈ HÀM
// 7. GỌI HÀM CỦA LỚP CHA BẰNG super
// ------------------------------------------

class Cho : DongVat() {

    override val ten = "Chó"

    override fun phatRaAmThanh() {
        println("$ten nói: Gâu gâu!")
    }
}

class OTo(ten: String) : PhuongTien(ten) {

    override fun diChuyen() {
        super.diChuyen()
        println("$ten đang chạy trên đường.")
    }
}


// ------------------------------------------
// HÀM CÓ SỐ LƯỢNG ĐỐI SỐ THAY ĐỔI
// ------------------------------------------

fun tinhTong(vararg cacSo: Int): Int {
    var tong = 0

    for (so in cacSo) {
        tong += so
    }

    return tong
}


// ==========================================
// HÀM MAIN
// ==========================================

fun main() {

    println("===== BÀI 2: KOTLIN =====")


    // ======================================
    // PHẦN A - LỚP TRỪU TƯỢNG
    // ======================================

    println("\n--- 1. LỚP TRỪU TƯỢNG ---")

    val cho = Cho()

    println("Tên động vật: ${cho.ten}")
    cho.phatRaAmThanh()
    cho.ngu()


    // ======================================
    // PHẦN B - OPEN, KẾ THỪA, OVERRIDE
    // ======================================

    println("\n--- 2. OPEN VÀ KẾ THỪA ---")

    val oTo = OTo("Toyota")
    oTo.diChuyen()


    // ======================================
    // PHẦN C - DANH SÁCH CHỈ ĐỌC
    // ======================================

    println("\n--- 3. DANH SÁCH CHỈ ĐỌC ---")

    val traiCay = listOf(
        "Táo",
        "Cam",
        "Chuối",
        "Xoài"
    )

    println("Danh sách: $traiCay")

    // Lấy kích thước danh sách
    println("Số lượng phần tử: ${traiCay.size}")

    // Lấy phần tử đầu tiên
    println("Phần tử đầu tiên: ${traiCay.first()}")

    // Bản sao đảo ngược
    val traiCayDaoNguoc = traiCay.reversed()
    println("Danh sách đảo ngược: $traiCayDaoNguoc")


    // ======================================
    // PHẦN D - DANH SÁCH CÓ THỂ THAY ĐỔI
    // ======================================

    println("\n--- 4. DANH SÁCH CÓ THỂ THAY ĐỔI ---")

    val monAn = mutableListOf(
        "Phở",
        "Bún bò",
        "Cơm"
    )

    println("Ban đầu: $monAn")

    // Thêm
    monAn.add("Mì Quảng")
    println("Sau khi thêm: $monAn")

    // Sửa
    monAn[0] = "Phở bò"
    println("Sau khi sửa: $monAn")

    // Xóa
    monAn.remove("Cơm")
    println("Sau khi xóa: $monAn")


    // ======================================
    // PHẦN E - VÒNG LẶP for
    // ======================================

    println("\n--- 5. VÒNG LẶP FOR ---")

    for (mon in monAn) {
        println("Món ăn: $mon")
    }


    // ======================================
    // PHẦN F - VÒNG LẶP while
    // ======================================

    println("\n--- 6. VÒNG LẶP WHILE ---")

    var index = 0

    while (index < monAn.size) {
        println("Món ăn thứ ${index + 1}: ${monAn[index]}")
        index++
    }


    // ======================================
    // PHẦN G - CHUỖI
    // ======================================

    println("\n--- 7. CHUỖI ---")

    val ten = "Kotlin"

    // Số ký tự trong chuỗi
    println("Chuỗi: $ten")
    println("Số ký tự: ${ten.length}")

    // Biến trong mẫu chuỗi
    println("Tôi đang học $ten")

    // Biểu thức trong mẫu chuỗi
    println("$ten có ${ten.length} ký tự")


    // ======================================
    // PHẦN H - THAO TÁC GÁN TĂNG CƯỜNG
    // ======================================

    println("\n--- 8. THAO TÁC GÁN TĂNG CƯỜNG ---")

    var so = 10

    so += 5
    println("Sau so += 5: $so")

    so -= 2
    println("Sau so -= 2: $so")

    so *= 3
    println("Sau so *= 3: $so")

    so /= 2
    println("Sau so /= 2: $so")


    // ======================================
    // PHẦN I - with
    // ======================================

    println("\n--- 9. WITH ---")

    with(oTo) {
        println("Tên phương tiện: $ten")
        diChuyen()
    }


    // ======================================
    // PHẦN J - THƯ VIỆN TOÁN HỌC
    // ======================================

    println("\n--- 10. KOTLIN MATH ---")

    // Đã import sqrt
    println("Căn bậc hai của 25: ${sqrt(25.0)}")

    // PI đã được import
    println("Giá trị PI: $PI")

    // Tên đủ điều kiện, không cần import
    println("Giá trị E: ${kotlin.math.E}")


    // ======================================
    // PHẦN K - XÂU CHUỖI LỆNH GỌI
    // ======================================

    println("\n--- 11. XÂU CHUỖI LỆNH GỌI ---")

    val ketQuaChuoi = "  Kotlin Programming  "
        .trim()
        .uppercase()
        .replace(" ", "_")

    println("Kết quả: $ketQuaChuoi")


    // ======================================
    // PHẦN L - SỐ LƯỢNG ĐỐI SỐ THAY ĐỔI
    // ======================================

    println("\n--- 12. VARARG ---")

    println("Tổng 1, 2, 3 = ${tinhTong(1, 2, 3)}")
    println("Tổng 10, 20, 30, 40 = ${tinhTong(10, 20, 30, 40)}")


    println("\n===== KẾT THÚC BÀI 2 =====")
}