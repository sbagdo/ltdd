// ================================
// BÀI 1 - KOTLIN CƠ BẢN
// ================================


// 1. Hàm không có đối số
fun loiChao() {
    println("Xin chào! Đây là hàm không có đối số.")
}


// 2. Hàm có đối số
fun chaoNguoiDung(ten: String) {
    println("Xin chào, $ten!")
}


// 3. Hàm trả về một giá trị
fun cong(a: Int, b: Int): Int {
    return a + b
}


// 4. Lớp đơn giản có thuộc tính và phương thức
class SinhVien {
    var ten = "Chưa có tên"
    var tuoi = 0

    fun gioiThieu() {
        println("Tên: $ten, Tuổi: $tuoi")
    }
}


// 5. Lớp có thông số
class Nguoi(val ten: String, var tuoi: Int) {

    fun gioiThieu() {
        println("Tên: $ten, Tuổi: $tuoi")
    }
}


// ================================
// HÀM MAIN - CHƯƠNG TRÌNH BẮT ĐẦU
// ================================

fun main() {

    println("===== BÀI 1: KOTLIN CƠ BẢN =====")


    // --------------------------------
    // 1. BIẾN VÀ KIỂU DỮ LIỆU
    // --------------------------------

    val hoTen: String = "Nguyen Van A"
    var tuoi: Int = 20
    val chieuCao: Double = 1.70
    val daDangKy: Boolean = true

    println("Họ tên: $hoTen")
    println("Tuổi: $tuoi")
    println("Chiều cao: $chieuCao")
    println("Đã đăng ký: $daDangKy")

    tuoi = 21
    println("Tuổi sau khi thay đổi: $tuoi")


    // --------------------------------
    // 2. IN BIẾN VỚI MẪU CHUỖI
    // --------------------------------

    println("Xin chào $hoTen!")
    println("$hoTen năm nay $tuoi tuổi.")

    val namSinh = 2026 - tuoi
    println("Năm sinh được tính là: $namSinh")

    // Dùng ${} để đưa biểu thức vào chuỗi
    println("$hoTen sinh khoảng năm ${2026 - tuoi}")


    // --------------------------------
    // 3. HÀM KHÔNG CÓ ĐỐI SỐ
    // --------------------------------

    loiChao()


    // --------------------------------
    // 4. HÀM CÓ ĐỐI SỐ
    // --------------------------------

    chaoNguoiDung(hoTen)
    chaoNguoiDung("Nguyen Van B")


    // --------------------------------
    // 5. HÀM TRẢ VỀ MỘT GIÁ TRỊ
    // --------------------------------

    val ketQuaCong = cong(10, 5)
    println("10 + 5 = $ketQuaCong")


    // --------------------------------
    // 6. TOÁN TỬ CƠ BẢN
    // --------------------------------

    val a = 10
    val b = 3

    println("a = $a, b = $b")
    println("a + b = ${a + b}")
    println("a - b = ${a - b}")
    println("a * b = ${a * b}")
    println("a / b = ${a / b}")
    println("a % b = ${a % b}")


    // --------------------------------
    // 7. TOÁN TỬ LOGIC
    // --------------------------------

    val daDuoi18 = tuoi >= 18
    val coTheDangKy = daDuoi18 && daDangKy

    println("Đủ 18 tuổi: $daDuoi18")
    println("Đã đăng ký: $daDangKy")
    println("Đủ điều kiện AND đã đăng ký: $coTheDangKy")

    println("Đủ 18 tuổi HOẶC đã đăng ký: ${daDuoi18 || daDangKy}")
    println("Phủ định của đã đăng ký: ${!daDangKy}")


    // --------------------------------
    // 8. SỐ NGẪU NHIÊN
    // --------------------------------

    val soNgauNhien = (1..10).random()
    println("Số ngẫu nhiên từ 1 đến 10: $soNgauNhien")


    // --------------------------------
    // 9. LẶP LẠI MỘT THAO TÁC BẰNG repeat()
    // --------------------------------

    println("Lặp lại 3 lần:")

    repeat(3) {
        println("Xin chào Kotlin!")
    }


    // --------------------------------
    // 10. LỒNG GHÉP VÒNG LẶP repeat()
    // --------------------------------

    println("Lồng ghép repeat:")

    repeat(3) { hang ->
        repeat(2) { cot ->
            println("Hàng ${hang + 1}, Cột ${cot + 1}")
        }
    }


    // --------------------------------
    // 11. CÂU LỆNH ĐIỀU KIỆN if / else
    // --------------------------------

    if (tuoi >= 18) {
        println("$hoTen đã đủ 18 tuổi.")
    } else {
        println("$hoTen chưa đủ 18 tuổi.")
    }


    // --------------------------------
    // 12. CÂU LỆNH ĐIỀU KIỆN when
    // --------------------------------

    val diem = 8

    when (diem) {
        10 -> println("Điểm $diem: Xuất sắc")
        8, 9 -> println("Điểm $diem: Giỏi")
        6, 7 -> println("Điểm $diem: Khá")
        else -> println("Điểm $diem: Cần cố gắng")
    }


    // --------------------------------
    // 13. CHỈ ĐỊNH KẾT QUẢ when CHO MỘT BIẾN
    // --------------------------------

    val xepLoai = when (diem) {
        10 -> "Xuất sắc"
        8, 9 -> "Giỏi"
        6, 7 -> "Khá"
        else -> "Cần cố gắng"
    }

    println("Xếp loại của sinh viên: $xepLoai")


    // --------------------------------
    // 14. LỚP ĐƠN GIẢN CÓ THUỘC TÍNH VÀ PHƯƠNG THỨC
    // --------------------------------

    val sinhVien1 = SinhVien()

    sinhVien1.ten = "Tran Thi B"
    sinhVien1.tuoi = 19

    sinhVien1.gioiThieu()


    // --------------------------------
    // 15. LỚP CÓ THÔNG SỐ
    // --------------------------------

    val nguoi1 = Nguoi("Le Van C", 22)

    nguoi1.gioiThieu()


    // --------------------------------
    // 16. TẠO THỰC THỂ
    // --------------------------------

    val nguoi2 = Nguoi("Pham Thi D", 20)
    val nguoi3 = Nguoi("Hoang Van E", 25)

    nguoi2.gioiThieu()
    nguoi3.gioiThieu()


    println("===== KẾT THÚC BÀI 1 =====")
}