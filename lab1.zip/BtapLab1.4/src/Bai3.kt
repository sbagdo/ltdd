// ==========================================
// BÀI 3 - COLLECTION VÀ TÍNH NĂNG KOTLIN
// ==========================================

import kotlin.properties.Delegates


// ------------------------------------------
// 1. ĐỐI TƯỢNG COMPANION
// ------------------------------------------

class SinhVien2(val ten: String) {

    companion object {
        const val TRUONG = "Trường Đại học Kotlin"

        fun thongTinTruong() {
            println("Tên trường: $TRUONG")
        }
    }
}


// ------------------------------------------
// 2. ỦY QUYỀN THUỘC TÍNH
// ------------------------------------------

class TaiKhoan {

    var tenNguoiDung: String by Delegates.observable("Chưa có tên") {
            _, giaTriCu, giaTriMoi ->
        println("Tên thay đổi: $giaTriCu -> $giaTriMoi")
    }
}


// ------------------------------------------
// 3. KHỞI TẠO TRỄ
// ------------------------------------------

class ThongTin {

    lateinit var noiDung: String

    fun hienThi() {
        println("Nội dung: $noiDung")
    }
}


// ==========================================
// HÀM MAIN
// ==========================================

fun main() {

    println("===== BÀI 3: COLLECTION VÀ KOTLIN =====")


    // ======================================
    // 1. TẠO MỘT NHÓM TỪ DANH SÁCH
    // ======================================

    println("\n--- 1. TẠO SET TỪ LIST ---")

    val danhSachSo = listOf(1, 2, 2, 3, 4, 4, 5)
    val nhomTuDanhSach = danhSachSo.toSet()

    println("Danh sách ban đầu: $danhSachSo")
    println("Set tạo từ danh sách: $nhomTuDanhSach")


    // ======================================
    // 2. XÁC ĐỊNH MỘT NHÓM
    // ======================================

    println("\n--- 2. XÁC ĐỊNH SET ---")

    val mauSac = setOf("Đỏ", "Xanh", "Vàng", "Đỏ")

    println("Set màu sắc: $mauSac")


    // ======================================
    // 3. PHÉP TOÁN TRÊN NHÓM
    // ======================================

    println("\n--- 3. PHÉP TOÁN TRÊN SET ---")

    val nhomA = setOf(1, 2, 3, 4)
    val nhomB = setOf(3, 4, 5, 6)

    println("Nhóm A: $nhomA")
    println("Nhóm B: $nhomB")

    println("Hợp: ${nhomA union nhomB}")
    println("Giao: ${nhomA intersect nhomB}")
    println("Hiệu A - B: ${nhomA subtract nhomB}")


    // ======================================
    // 4. XÁC ĐỊNH MAP CÓ THỂ THAY ĐỔI
    // ======================================

    println("\n--- 4. MUTABLE MAP ---")

    val diemSinhVien = mutableMapOf(
        "An" to 8,
        "Bình" to 9
    )

    println("Map ban đầu: $diemSinhVien")


    // ======================================
    // 5. ĐẶT GIÁ TRỊ TRONG MAP
    // ======================================

    diemSinhVien["Lan"] = 10
    diemSinhVien["An"] = 9

    println("Map sau khi thêm/sửa: $diemSinhVien")


    // ======================================
    // 6. LẶP LẠI TẬP HỢP
    // ======================================

    println("\n--- 5. LẶP QUA COLLECTION ---")

    val cacSo = listOf(1, 2, 3, 4, 5)

    cacSo.forEach { so ->
        println("Số: $so")
    }


    // ======================================
    // 7. CHUYỂN ĐỔI TỪNG MỤC
    // ======================================

    println("\n--- 6. MAP() ---")

    val binhPhuong = cacSo.map { so ->
        so * so
    }

    println("Danh sách ban đầu: $cacSo")
    println("Bình phương: $binhPhuong")


    // ======================================
    // 8. LỌC CÁC MỤC
    // ======================================

    println("\n--- 7. FILTER() ---")

    val soChan = cacSo.filter { so ->
        so % 2 == 0
    }

    println("Số chẵn: $soChan")


    // ======================================
    // 9. CÁC PHÉP TOÁN KHÁC
    // ======================================

    println("\n--- 8. PHÉP TOÁN KHÁC ---")

    println("Số lượng: ${cacSo.count()}")
    println("Tổng: ${cacSo.sum()}")
    println("Phần tử lớn nhất: ${cacSo.maxOrNull()}")
    println("Phần tử nhỏ nhất: ${cacSo.minOrNull()}")
    println("Có số lớn hơn 4: ${cacSo.any { it > 4 }}")
    println("Tất cả đều > 0: ${cacSo.all { it > 0 }}")


    // ======================================
    // 10. HÀM PHẠM VI let
    // ======================================

    println("\n--- 9. LET ---")

    val ten: String? = "Kotlin"

    ten?.let {
        println("Độ dài của $it là ${it.length}")
    }


    // ======================================
    // 11. HÀM PHẠM VI apply
    // ======================================

    println("\n--- 10. APPLY ---")

    val danhSach = mutableListOf<String>().apply {
        add("Táo")
        add("Cam")
        add("Chuối")
    }

    println("Danh sách tạo bằng apply: $danhSach")


    // ======================================
    // 12. THUỘC TÍNH DỰ PHÒNG
    // ======================================

    println("\n--- 11. THUỘC TÍNH DỰ PHÒNG ---")

    val tenNguoiDung: String? = null

    val tenHienThi = tenNguoiDung ?: "Khách"

    println("Tên hiển thị: $tenHienThi")


    // ======================================
    // 13. LỆNH GỌI AN TOÀN
    // ======================================

    println("\n--- 12. SAFE CALL ---")

    val email: String? = null

    println("Độ dài email: ${email?.length}")


    // ======================================
    // 14. HÀM LAMBDA
    // ======================================

    println("\n--- 13. LAMBDA ---")

    val nhanDoi: (Int) -> Int = { so ->
        so * 2
    }

    println("Gấp đôi 5 = ${nhanDoi(5)}")


    // ======================================
    // 15. COMPANION OBJECT
    // ======================================

    println("\n--- 14. COMPANION OBJECT ---")

    println("Trường: ${SinhVien2.TRUONG}")
    SinhVien2.thongTinTruong()


    // ======================================
    // 16. ỦY QUYỀN THUỘC TÍNH
    // ======================================

    println("\n--- 15. DELEGATED PROPERTY ---")

    val taiKhoan = TaiKhoan()

    println("Tên ban đầu: ${taiKhoan.tenNguoiDung}")

    taiKhoan.tenNguoiDung = "Nguyen Van A"
    taiKhoan.tenNguoiDung = "Tran Thi B"


    // ======================================
    // 17. KHỞI TẠO TRỄ
    // ======================================

    println("\n--- 16. LATEINIT ---")

    val thongTin = ThongTin()

    thongTin.noiDung = "Đây là dữ liệu được khởi tạo sau."
    thongTin.hienThi()


    // ======================================
    // 18. TOÁN TỬ ELVIS
    // ======================================

    println("\n--- 17. TOÁN TỬ ELVIS ---")

    val soDienThoai: String? = null

    val ketQua = soDienThoai ?: "Chưa có số điện thoại"

    println(ketQua)


    println("\n===== KẾT THÚC BÀI 3 =====")
}