// ==========================================
// BÀI 4 - COROUTINE VÀ CÁC KIẾN THỨC KHÁC
// ==========================================

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking


// ------------------------------------------
// 1. KHAI BÁO HÀM TẠM NGƯNG
// ------------------------------------------

suspend fun hamTamNgung() {
    println("Hàm tạm ngưng bắt đầu.")
    delay(1000)
    println("Hàm tạm ngưng kết thúc.")
}


// ------------------------------------------
// 2. GỌI HÀM TẠM NGƯNG TỪ MỘT
//    HÀM TẠM NGƯNG KHÁC
// ------------------------------------------

suspend fun hamTamNgungKhac() {
    println("Bắt đầu hàm tạm ngưng khác.")

    hamTamNgung()

    println("Kết thúc hàm tạm ngưng khác.")
}


// ------------------------------------------
// 3. HÀM TẠM NGƯNG DÙNG CHO async
// ------------------------------------------

suspend fun tinhTongSauKhiCho(a: Int, b: Int): Int {
    delay(1000)
    return a + b
}


// ------------------------------------------
// 4. KHAI BÁO OBJECT
// ------------------------------------------

object ThongBao {
    fun hienThi() {
        println("Đây là một đối tượng object trong Kotlin.")
    }
}


// ------------------------------------------
// 5. TẠO ENUM CLASS
// ------------------------------------------

enum class TrangThai {
    MOI,
    DANG_XU_LY,
    HOAN_THANH,
    HUY
}


// ==========================================
// HÀM MAIN
// ==========================================

fun main() = runBlocking {

    println("===== BÀI 4: COROUTINE VÀ KOTLIN =====")


    // ======================================
    // 1. CHẠY HÀM TẠM NGƯNG
    //    runBlocking chặn luồng hiện tại
    //    cho đến khi coroutine hoàn tất
    // ======================================

    println("\n--- 1. SUSPEND VÀ RUNBLOCKING ---")

    hamTamNgung()


    // ======================================
    // 2. GỌI MỘT HÀM SUSPEND
    //    TỪ HÀM SUSPEND KHÁC
    // ======================================

    println("\n--- 2. GỌI SUSPEND TỪ SUSPEND ---")

    hamTamNgungKhac()


    // ======================================
    // 3. GLOBALSCOPE.LAUNCH
    // ======================================

    println("\n--- 3. GLOBALSCOPE.LAUNCH ---")

    GlobalScope.launch {
        println("Coroutine GlobalScope bắt đầu.")

        delay(1000)

        println("Coroutine GlobalScope kết thúc.")
    }

    // Chờ để coroutine có thời gian chạy
    delay(1500)


    // ======================================
    // 4. TRUY CẬP JOB COROUTINE
    // ======================================

    println("\n--- 4. JOB ---")

    val job: Job = launch {
        println("Job đang bắt đầu.")

        delay(1000)

        println("Job đã hoàn thành.")
    }

    println("Job có đang hoạt động: ${job.isActive}")

    // Chờ Job hoàn thành
    job.join()

    println("Job đã hoàn thành: ${job.isCompleted}")


    // ======================================
    // 5. HỦY JOB COROUTINE
    // ======================================

    println("\n--- 5. HỦY JOB ---")

    val jobCanHuy = launch {

        repeat(10) { lan ->
            println("Đang chạy lần ${lan + 1}")

            delay(500)
        }
    }

    // Chờ Job chạy một lúc
    delay(1200)

    println("Đang hủy Job...")

    jobCanHuy.cancel()

    println("Job đã bị hủy: ${jobCanHuy.isCancelled}")


    // ======================================
    // 6. ASYNC VÀ AWAIT
    // ======================================

    println("\n--- 6. ASYNC / AWAIT ---")

    val ketQuaAsync = async {
        tinhTongSauKhiCho(10, 20)
    }

    println("Đang chờ kết quả không đồng bộ...")

    val ketQua = ketQuaAsync.await()

    println("Kết quả: $ketQua")


    // ======================================
    // 7. OBJECT
    // ======================================

    println("\n--- 7. OBJECT ---")

    ThongBao.hienThi()


    // ======================================
    // 8. TRY / CATCH - PHÁT HIỆN NGOẠI LỆ
    // ======================================

    println("\n--- 8. TRY / CATCH ---")

    try {
        val so = 10
        val soKhac = 0

        val ketQuaChia = so / soKhac

        println("Kết quả: $ketQuaChia")

    } catch (e: ArithmeticException) {

        println("Đã phát hiện ngoại lệ: ${e.message}")
    }


    // ======================================
    // 9. ENUM CLASS
    // ======================================

    println("\n--- 9. ENUM CLASS ---")

    val trangThai = TrangThai.DANG_XU_LY

    println("Trạng thái hiện tại: $trangThai")


    // ======================================
    // 10. KIỂM TRA GIÁ TRỊ ENUM BẰNG when
    // ======================================

    println("\n--- 10. KIỂM TRA ENUM ---")

    when (trangThai) {
        TrangThai.MOI ->
            println("Đơn hàng mới.")

        TrangThai.DANG_XU_LY ->
            println("Đơn hàng đang được xử lý.")

        TrangThai.HOAN_THANH ->
            println("Đơn hàng đã hoàn thành.")

        TrangThai.HUY ->
            println("Đơn hàng đã bị hủy.")
    }


    println("\n===== KẾT THÚC BÀI 4 =====")
}