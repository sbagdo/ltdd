package com.example.authentication

import android.util.Patterns
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest

@Composable
fun SignUp(navController: NavController) {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_LONG).show()

    fun doSignUp() {
        when {
            name.isBlank() -> toast("Nhập tên của bạn nha 😎")
            !Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> toast("Email chưa đúng định dạng 🥲")
            password.length < 6 -> toast("Mật khẩu tối thiểu 6 ký tự nha")
            password != confirm -> toast("Mật khẩu nhập lại chưa khớp 🙃")
            else -> {
                loading = true
                auth.createUserWithEmailAndPassword(email.trim(), password)
                    .addOnCompleteListener { task ->
                        if (!task.isSuccessful) {
                            loading = false
                            toast(authErrorMessage(task.exception))
                            return@addOnCompleteListener
                        }

                        val user = task.result?.user
                        val profile = UserProfileChangeRequest.Builder()
                            .setDisplayName(name.trim())
                            .build()

                        // Lưu tên hiển thị + gửi email xác thực rồi vào Home
                        user?.updateProfile(profile)?.addOnCompleteListener {
                            user.sendEmailVerification()
                            loading = false
                            toast("Tạo tài khoản thành công 🎉 Check mail để xác thực nhé!")
                            navController.navigate(Screen.Home.rout) {
                                popUpTo(navController.graph.id) { inclusive = true }
                            }
                        } ?: run { loading = false }
                    }
            }
        }
    }

    AuthBackground {
        Text("🚀", fontSize = 56.sp)
        Spacer(Modifier.height(8.dp))
        GradientTitle("Tạo tài khoản mới")
        Text(
            "Gia nhập hội chỉ trong 30 giây ⚡",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 14.sp
        )

        Spacer(Modifier.height(28.dp))

        GlassCard {
            GenZTextField(
                value = name,
                onValueChange = { name = it },
                label = "Tên của bạn",
                icon = "👤"
            )
            Spacer(Modifier.height(14.dp))
            GenZTextField(
                value = email,
                onValueChange = { email = it },
                label = "Email",
                icon = "📧",
                keyboardType = KeyboardType.Email
            )
            Spacer(Modifier.height(14.dp))
            GenZTextField(
                value = password,
                onValueChange = { password = it },
                label = "Mật khẩu",
                icon = "🔒",
                isPassword = true,
                keyboardType = KeyboardType.Password
            )
            Spacer(Modifier.height(14.dp))
            GenZTextField(
                value = confirm,
                onValueChange = { confirm = it },
                label = "Nhập lại mật khẩu",
                icon = "🔐",
                isPassword = true,
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done,
                onDone = { doSignUp() }
            )
            Spacer(Modifier.height(22.dp))

            GradientButton(text = "Đăng ký ✨", loading = loading) { doSignUp() }
        }

        Spacer(Modifier.height(24.dp))

        Row {
            Text("Đã có tài khoản? ", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
            Text(
                "Đăng nhập",
                color = GenZPink,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { navController.popBackStack() }
            )
        }
    }
}
