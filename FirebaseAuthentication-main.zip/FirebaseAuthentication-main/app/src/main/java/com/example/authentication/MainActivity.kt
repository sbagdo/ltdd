package com.example.authentication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.widget.Toast
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Mynavigation()
            }
        }
    }
}

/** Các màn hình trong app */
sealed class Screen(val rout: String) {
    object Signin : Screen("signin")
    object Signup : Screen("signup")
    object Home : Screen("home")
}

@Composable
fun Mynavigation() {
    val navController = rememberNavController()

    // Đã đăng nhập từ trước thì vào thẳng Home, chưa thì vào Sign In
    val startDestination = if (FirebaseAuth.getInstance().currentUser != null) {
        Screen.Home.rout
    } else {
        Screen.Signin.rout
    }

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Screen.Signin.rout) { SignIn(navController = navController) }
        composable(Screen.Signup.rout) { SignUp(navController = navController) }
        composable(Screen.Home.rout) { HomeScreen(navController = navController) }
    }
}

@Composable
fun HomeScreen(navController: NavController) {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    val user = auth.currentUser

    var verified by remember { mutableStateOf(user?.isEmailVerified == true) }

    val displayName = user?.displayName?.takeIf { it.isNotBlank() }
        ?: user?.email?.substringBefore("@")
        ?: "bạn"

    AuthBackground {
        // Avatar
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(GenZPurple, GenZPink, GenZCyan))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = displayName.first().uppercase(),
                color = Color.White,
                fontSize = 40.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }

        Spacer(Modifier.height(20.dp))
        Text(
            text = "Hello, $displayName 🔥",
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center
        )
        Text(
            text = "Bạn đã đăng nhập thành công ✨",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 14.sp
        )

        Spacer(Modifier.height(28.dp))

        GlassCard {
            InfoRow("📧 Email", user?.email ?: "-")
            Spacer(Modifier.height(14.dp))
            InfoRow("🆔 UID", user?.uid?.take(14)?.plus("…") ?: "-")
            Spacer(Modifier.height(14.dp))
            InfoRow(
                "✅ Xác thực email",
                if (verified) "Đã xác thực" else "Chưa xác thực"
            )
        }

        Spacer(Modifier.height(20.dp))

        if (!verified) {
            GradientButton(text = "Gửi lại email xác thực 💌", loading = false) {
                user?.sendEmailVerification()?.addOnCompleteListener {
                    Toast.makeText(
                        context,
                        if (it.isSuccessful) "Đã gửi email xác thực, check hộp thư nhé 📬"
                        else "Gửi thất bại, thử lại sau nha",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlineActionButton(text = "Mình xác thực rồi, làm mới 🔄") {
                user?.reload()?.addOnCompleteListener {
                    verified = auth.currentUser?.isEmailVerified == true
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        OutlineActionButton(text = "Đăng xuất 👋") {
            auth.signOut()
            navController.navigate(Screen.Signin.rout) {
                popUpTo(navController.graph.id) { inclusive = true }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column {
        Text(label, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun OutlineActionButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(BorderStroke(1.5.dp, Color.White.copy(alpha = 0.25f)), RoundedCornerShape(20.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}
