package com.example.authentication

import android.util.Patterns
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException

// ---------- Màu sắc Gen Z ----------
val GenZBg = Color(0xFF0F0A1F)
val GenZBgSecondary = Color(0xFF1B1038)
val GenZPurple = Color(0xFF7C4DFF)
val GenZPink = Color(0xFFFF4D8D)
val GenZCyan = Color(0xFF22D3EE)

// ---------- Màn hình Sign In ----------
@Composable
fun SignIn(navController: NavController) {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    fun doSignIn() {
        when {
            !Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() ->
                Toast.makeText(context, "Email chưa đúng định dạng 🥲", Toast.LENGTH_SHORT).show()
            password.length < 6 ->
                Toast.makeText(context, "Mật khẩu tối thiểu 6 ký tự nha", Toast.LENGTH_SHORT).show()
            else -> {
                loading = true
                auth.signInWithEmailAndPassword(email.trim(), password)
                    .addOnCompleteListener { task ->
                        loading = false
                        if (task.isSuccessful) {
                            Toast.makeText(context, "Đăng nhập thành công 🎉", Toast.LENGTH_SHORT).show()
                            navController.navigate(Screen.Home.rout) {
                                popUpTo(navController.graph.id) { inclusive = true }
                            }
                        } else {
                            Toast.makeText(context, authErrorMessage(task.exception), Toast.LENGTH_LONG).show()
                        }
                    }
            }
        }
    }

    AuthBackground {
        Text("👋", fontSize = 56.sp)
        Spacer(Modifier.height(8.dp))
        GradientTitle("Chào mừng trở lại")
        Text(
            "Đăng nhập để tiếp tục vibe nhé ✨",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 14.sp
        )

        Spacer(Modifier.height(28.dp))

        GlassCard {
            GenZTextField(
                value = email,
                onValueChange = { email = it },
                label = "Email",
                icon = "📧",
                keyboardType = KeyboardType.Email
            )
            Spacer(Modifier.height(14.dp))
            GenZTextField(
                value = password,
                onValueChange = { password = it },
                label = "Mật khẩu",
                icon = "🔒",
                isPassword = true,
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done,
                onDone = { doSignIn() }
            )

            Text(
                text = "Quên mật khẩu?",
                color = GenZCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.End)
                    .padding(top = 10.dp, bottom = 18.dp)
                    .clickable {
                        if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
                            Toast.makeText(context, "Nhập email trước đã nha 📧", Toast.LENGTH_SHORT).show()
                        } else {
                            auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener {
                                Toast.makeText(
                                    context,
                                    if (it.isSuccessful) "Đã gửi link đặt lại mật khẩu, check mail nhé 📬"
                                    else authErrorMessage(it.exception),
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
            )

            GradientButton(text = "Đăng nhập 🚀", loading = loading) { doSignIn() }
        }

        Spacer(Modifier.height(24.dp))

        Row {
            Text("Chưa có tài khoản? ", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
            Text(
                "Đăng ký ngay",
                color = GenZPink,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { navController.navigate(Screen.Signup.rout) }
            )
        }
    }
}

// ---------- Các component dùng chung (SignUp & Home cũng dùng) ----------

@Composable
fun AuthBackground(content: @Composable ColumnScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(GenZBg, GenZBgSecondary)))
    ) {
        // Vệt sáng trang trí
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = 90.dp, y = (-90).dp)
                .size(320.dp)
                .background(
                    Brush.radialGradient(listOf(GenZPink.copy(alpha = 0.40f), Color.Transparent)),
                    CircleShape
                )
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .offset(x = (-100).dp, y = 100.dp)
                .size(340.dp)
                .background(
                    Brush.radialGradient(listOf(GenZPurple.copy(alpha = 0.45f), Color.Transparent)),
                    CircleShape
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            content = content
        )
    }
}

@Composable
fun GradientTitle(text: String) {
    Text(
        text = text,
        style = TextStyle(
            brush = Brush.horizontalGradient(listOf(GenZCyan, GenZPurple, GenZPink)),
            fontSize = 30.sp,
            fontWeight = FontWeight.ExtraBold
        ),
        textAlign = TextAlign.Center
    )
}

@Composable
fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = Color.White.copy(alpha = 0.06f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
    ) {
        Column(modifier = Modifier.padding(20.dp), content = content)
    }
}

@Composable
fun GenZTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    icon: String,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next,
    onDone: (() -> Unit)? = null
) {
    var visible by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true,
        shape = RoundedCornerShape(20.dp),
        leadingIcon = { Text(icon, fontSize = 18.sp) },
        trailingIcon = if (isPassword) {
            {
                IconButton(onClick = { visible = !visible }) {
                    Text(if (visible) "🙈" else "👁️", fontSize = 18.sp)
                }
            }
        } else null,
        visualTransformation = if (isPassword && !visible) PasswordVisualTransformation()
        else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            cursorColor = GenZCyan,
            focusedBorderColor = GenZCyan,
            unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
            focusedContainerColor = Color.White.copy(alpha = 0.06f),
            unfocusedContainerColor = Color.White.copy(alpha = 0.04f),
            focusedLabelColor = GenZCyan,
            unfocusedLabelColor = Color.White.copy(alpha = 0.5f),
            focusedLeadingIconColor = GenZCyan,
            unfocusedLeadingIconColor = Color.White.copy(alpha = 0.5f),
            focusedTrailingIconColor = GenZCyan,
            unfocusedTrailingIconColor = Color.White.copy(alpha = 0.5f)
        )
    )
}

@Composable
fun GradientButton(text: String, loading: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(GenZPurple, GenZPink)))
            .clickable(enabled = !loading, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (loading) {
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 2.5.dp,
                modifier = Modifier.size(24.dp)
            )
        } else {
            Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

/** Chuyển lỗi Firebase sang tiếng Việt dễ hiểu */
fun authErrorMessage(e: Exception?): String = when (e) {
    is FirebaseAuthInvalidUserException -> "Tài khoản không tồn tại hoặc đã bị khóa 😵"
    is FirebaseAuthInvalidCredentialsException -> "Email hoặc mật khẩu chưa đúng 🙈"
    is FirebaseAuthUserCollisionException -> "Email này đã được đăng ký rồi 👀"
    is FirebaseAuthWeakPasswordException -> "Mật khẩu quá yếu, đặt mạnh hơn nha 💪"
    is FirebaseAuthException -> "Lỗi Firebase [${e.errorCode}]: ${e.localizedMessage}"
    else -> e?.localizedMessage ?: "Có lỗi xảy ra, thử lại sau nhé"
}
